import React from 'react';

const UserPage = () => {
  return (
    <div>
      <h2>Welcome, User!</h2>
      <p>You can now view and book your tickets.</p>
    </div>
  );
};

export default UserPage;