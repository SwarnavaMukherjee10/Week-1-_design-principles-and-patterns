import React from 'react';

const GuestPage = () => {
  return (
    <div>
      <h2>Welcome, Guest!</h2>
      <p>Browse flights and deals. Please login to book your tickets.</p>
    </div>
  );
};

export default GuestPage;